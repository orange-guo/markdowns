docker-compose kill
docker-compose rm -f
umount -l ./Aliyundrive
rm -r ./Aliyundrive
